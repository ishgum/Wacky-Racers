/** @file   target.h
    @author M. P. Hayes, UCECE
    @date   22 April 2015
    @brief 
*/
#ifndef TARGET_H
#define TARGET_H

#include "mat91lib.h"

/* This is for the modified sam4sbasic2 board.  The only difference
   between it and the older board is that it uses an 12 MHz crystal
   instead of a 18.432 MHz crystal.  */

/* System clocks  */
#define F_XTAL 12e6
#define MCU_PLL_MUL 16
#define MCU_PLL_DIV 1
#define MCU_USB_DIV 2
/* 192 MHz  */
#define F_PLL (F_XTAL / MCU_PLL_DIV * MCU_PLL_MUL)
/* 96 MHz  */
#define F_CPU (F_PLL / 2)

// LEDs
#define LED1_PIO PA21_PIO
#define LED2_PIO PA22_PIO
#define LED3_PIO PA23_PIO

// Onboard tactile input
#define DIPSW1_PIO PA30_PIO
#define DIPSW2_PIO PA29_PIO
#define DIPSW3_PIO PA28_PIO
#define DIPSW4_PIO PA27_PIO
#define SLEEP_PIO PA31_PIO

// IR Data input
#define IRDATA_PIO PA26_PIO

// Car control
#define MOTORPWM_PIO PB0_PIO
#define STEERINGPWM_PIO PB1_PIO
#define RXPOWER_PIO PA5_PIO
#define M2POWER_PIO PA17_PIO

// Analog inputs, can be reconfig. for PWM or digital output
//#define ADC1_PIO
//#define ADC2_PIO

// USB detect
#define UDP_VBUS_PIO PA5_PIO
#define USB1_PB11 PB11_PIO
#define USB2_PB10 PB10_PIO

#endif /* TARGET_H  */
