/** @file   config.h
    @author M. P. Hayes, UCECE
    @date   02 June 2007
    @brief 
*/
#ifndef CONFIG_H
#define CONFIG_H

#include "mat91lib.h"
#include "target.h"


#endif /* CONFIG_H  */
