/** @file   target.h
    @author M. P. Hayes, UCECE
    @date   22 April 2015
    @brief 
*/
#ifndef TARGET_H
#define TARGET_H

#include "mat91lib.h"

/* This is for the original sam4sbasic board.  The only difference
   between it and the newer board is that it uses an 18.432 MHz
   crystal instead of a 12 MHz crystal.  The SAM4S PLL is not as
   flexible as the SAM7S PLL (the maximum multiplier is reduced to 80)
   and it is not possible to achieve an exact 96 MHz clock. 

   In principle, a multiplier of 73 and a divisor of 7 should produce
   F_PLL to 192.219 MHz.  However, F_XTAL / 7 is less than the minimum
   of 3 MHz for the PLL.

   A multiplier of 32 and a divisor of 3 giving 196.61 MHz for F_PLL
   makes the USB work.  */

// System clocks
#define F_XTAL 18.432e6
#define MCU_PLL_MUL 52
#define MCU_PLL_DIV 5
#define MCU_USB_DIV 2
// 191.69 MHz
#define F_PLL (F_XTAL / MCU_PLL_DIV * MCU_PLL_MUL)
// 95.845 MHz
#define F_CPU (F_PLL / 2)

#define LED1_PIO PB3_PIO            // RED
#define LED2_PIO PB2_PIO            // AMBER
#define LED3_PIO PB1_PIO            // GREEN

#define TCM8230_RESET_PIO PA20_PIO  // RESET

#define TCM8230_VD_PIO PA13_PIO     // VSYNC
#define TCM8230_HD_PIO PA25_PIO     // HSYNC
#define TCM8230_DCLK_PIO PA5_PIO    // DCLK
#define TCM8230_EXTCLK_PIO PA0_PIO  // EXTCLK

#define TCM8230_DATA_PIOBUS PIOBUS_DEFINE(PORT_A, 6, 13) // this runs 1 over the end.
/*
PA6 --> PA12 + PA27
I didn't define the camera on continuous ports, so we'll need to patch
the tcm8230 driver so accomodate this.

*/

#define TCM8230_DATA0 PA6_PIO
#define TCM8230_DATA1 PA7_PIO
#define TCM8230_DATA2 PA8_PIO
#define TCM8230_DATA3 PA9_PIO

#define TCM8230_DATA4 PA10_PIO
#define TCM8230_DATA5 PA11_PIO
#define TCM8230_DATA6 PA12_PIO
#define TCM8230_DATA7 PA26_PIO // Note the jump!

// This has been patched to replace the MSB with D7 instead of whatever's on PA13_PIO
        //*buffer++ = (((piobus_input_get (TCM8230_DATA_PIOBUS)) & 0x7F) |
        //    (((pio_input_get(TCM8230_DATA7)) << 7) & 0x80));

#define TCM8230_SDA_PIO PA22_PIO // Camera i2c
#define TCM8230_SCL_PIO PA23_PIO

#define UDP_VBUS_PIO PA24_PIO // USB-DETECT

#define SCL_PIO PA4_PIO // Inter-board i2c
#define SDA_PIO PA3_PIO

#define REG_ENABLE_1 PB0_PIO  // 2.8v regulator enable.
#define REG_ENABLE_2 PA18_PIO // 1.5v regulator enable.

#define DIP_SWITCH_1 PA30_PIO // Dip-switches on board. (PIO_PULLUP)
#define DIP_SWITCH_2 PA29_PIO
#define DIP_SWITCH_3 PA28_PIO
#define DIP_SWITCH_4 PA27_PIO

#define HEADER_1 PA17_PIO // On-board header.
#define HEADER_2 PA16_PIO
#define HEADER_3 PA15_PIO
#define HEADER_4 PA14_PIO


#endif /* TARGET_H  */