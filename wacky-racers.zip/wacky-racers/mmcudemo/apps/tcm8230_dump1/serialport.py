import serial
import sys
frame_begin = '*'
ser = serial.Serial('/dev/cu.usbmodem1411', 115200, timeout=1)
ser.write("1\r");
while 1:
	line = ser.readline()
	print line
	
ser.close()