import serial
import sys
frame_begin = '*'
ser = serial.Serial('/dev/cu.usbmodem1411', 115200, timeout=1)
# or usbmodem1411

count = 0
ser.write("1\r");
# Wait for a * which denotes the beginning of the frame.
while 1:
	line = ser.readline()
	if frame_begin in line:
		count = count + 1
		
	if count > 0:
		break
		
	if 'error' in line:
		print line
		sys.exit()

ser.write("1\r");
# Print the output of the file to the console until a * is recieved,
# because this indicates the beginning of the next frame.
while 1:
	line = ser.readline()
	if frame_begin in line:
		break
		
	# Don't print empty lines.
	if len(line) > 40:
		# Don't print newline characters, print already does this.
		print (line.replace('\r\n', ''))
	
ser.close()