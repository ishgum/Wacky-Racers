python imagecap.py > /tmp/pic3.txt
python colourdisplay.py /tmp/pic3.txt