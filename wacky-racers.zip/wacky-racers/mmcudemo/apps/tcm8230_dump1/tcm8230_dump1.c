/* File:   tcm8230_dump1.c
   Author: M. P. Hayes, UCECE
   Date:   21 Apr 2013
   Descr: 
*/
#include "tcm8230.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <twi.h>
#include "usb_cdc.h"
#include "sys.h"
#include "led.h"
#include "pacer.h"

// i2c slave address of the board.
#define SLAVE_ADDR 0x21
#define LOOP_POLL_RATE 2000
#define TIMEOUT_US 2000
#define INTERNAL_ADDR_SIZE 1
#define SEND_MESSAGE_SIZE 97
#define RECV_MESSAGE_SIZE 8

#define LED_FLASH_FREQ 2

#define LINEBUFFER_SIZE 80
static int char_count = 0;
static char linebuffer[LINEBUFFER_SIZE];

int16_t led_capture_decay = 0;
int16_t led_linereq_decay = 0;

// Peripherals.
usb_cdc_t usb_cdc;
twi_t twi;

// Configure TWI peripheral.
static const twi_cfg_t twi_cfg =
{
    .slave_addr = SLAVE_ADDR,
    .channel = 0
};

// LEDs configuration.
static const led_cfg_t leds_cfg[] =
{
    {
        .pio = LED1_PIO,
        .active = 0
    },
    {
        .pio = LED2_PIO,
        .active = 0
    },
    {
        .pio = LED3_PIO,
        .active = 0
    }
};

enum {LEDS_NUM = ARRAY_SIZE (leds_cfg)};
led_t leds[LEDS_NUM];

// Configure the tcm8230 peripheral.
static const tcm8230_cfg_t cfg =
{
    .picsize = TCM8230_PICSIZE_SQCIF,
    .colour = true
};

// Create the image buffer.
static uint8_t image[SQCIF_WIDTH * SQCIF_HEIGHT * 2] = { 0 };
static int32_t image_ret = 0;

// Wraps the fprintf function when printing to the seiral port.
void write_log(const char *format, ...)
{
    if (!pio_input_get(DIP_SWITCH_1))
        return;
    
    va_list args;
    va_start(args, format);

    vfprintf(stderr, format, args);

    va_end(args);
}

// Prints the image over the USB port.
static void image_dump (uint8_t *image, unsigned int rows, unsigned int cols)
{
    unsigned int row;
    unsigned int col;

    write_log ("**************\r\n");
    for (row = 0; row < rows; row++)
    {
        write_log ("%3d: ", row);
        for (col = 0; col < cols * 2; col++)
            write_log ("%3d, ", image[row * cols * 2 + col]);
        write_log ("\r\n");
    }
    write_log ("\r\n");
}

static int32_t image_capture(void)
{
    // IMAGE CAPTURE ROUTINE.
    led_set (leds[1], 1);
    while ( tcm8230_frame_ready_p ())
        continue;
    
    // Wait until the next frame is ready to capture.
    led_set (leds[1], 0);
    while (! tcm8230_frame_ready_p ())
        continue;
    
    // Signify that we are currently capturing.
    led_set (leds[1], 1);
    led_capture_decay = 2000;
    
    // Capture the image and store the return code.
    return tcm8230_capture (image, sizeof(image), 200);
}

static void sub_image(uint16_t offset, char* image_block)
{
    memcpy(image_block, image + (96*offset), 96);    
}

void twi_poll (twi_t twi)
{
    static char message[SEND_MESSAGE_SIZE];
    static uint8_t addr;
    twi_ret_t ret;
    char packet[RECV_MESSAGE_SIZE + INTERNAL_ADDR_SIZE];

	// Check for any messages.
    ret = twi_slave_poll (twi);
    switch (ret)
    {
        case TWI_IDLE:
    		// Do nothing.
            break;
            
        case TWI_WRITE:
            write_log ("WRITE REQUEST... ");
            ret = twi_slave_read (twi, &packet, sizeof(packet));
            if (ret < 0)
            {
                // An error of some sort.
                write_log ("error: %3d\r\n", ret);
            }
            else if (ret == 1)
            {
                // We've been sent a one-byte internal address.
                // This corresponds to the image line that the
                // master is requesting.
                addr = packet[0];
                write_log ("read: %3d\r\n", addr);
    			
                /* A read request will be hot on our heels.  */
                twi_poll (twi);
            }
            else if (ret != sizeof (packet)) // Something doesn't match up!
            {
                // Protocol error.
                write_log ("protocol error: %3d\r\n", ret);
            }
            else
            {
    			// We got a properly formed packet.
                addr = packet[0];
                
                // If it is sent to internal address 0, it is
                // telling us to capture an image.
                // ToDo: DO AN IMAGE CAPTURE.
                write_log ("image cap request: %3d\r\n", addr);
                if (addr == 0)
                {
                    write_log ("i2c_capturing... ");
                    image_ret = image_capture();
                    write_log ("done!\r\n");
                }
                
                // This will block until it is done.
            }
            break;
            
        // Recieved a read request.
        // The master wants us to send it a line.
        case TWI_READ:
            // Reply with a portion of the image.
            if (addr == 0)
                addr = 1;
            
            write_log ("Requesting line:%d...\r\n", addr);
            sub_image(addr - 1, message);
            message[96] = '\0';
            write_log ("%3d: %s\r\n", addr, message);
            led_set(leds[2], 0);
            ret = twi_slave_write (twi, message, sizeof(message));
            led_set(leds[2], 1);
            led_linereq_decay = 2000;
            
            // Detect errors
            if (ret != sizeof(message))   // 
                write_log ("failed with error: %d", ret);
            
            write_log ("done!\n");
            
            break;
            
        // Default case: do nothing.
        default:
            break;
    }
}

// USB Comms
static void process_command (void)
{
    char ch;
    char* msg;
    uint16_t addr = 0;
    
    char image_out[97];
    
    ch = fgetc (stdin);
    fputc (ch, stderr);
    if (char_count < LINEBUFFER_SIZE - 1)
        linebuffer[char_count++] = ch;

    if (ch != '\r')
        return;
    fputc ('\n', stderr);
    linebuffer[char_count++] = 0;
    char_count = 0;

    switch (linebuffer[0])
    {
    case '0':
        write_log ("Capturing image... ");
        image_ret = image_capture();
        write_log ("done!\n");
        break;
        
    case '1':
        write_log ("Image dump follows\n");
        image_dump(image, SQCIF_HEIGHT, SQCIF_WIDTH);
        break;
        
    case 'r':
        msg = linebuffer + 1;
        while (*msg == ' ')
            msg++;
            
        addr = atoi(msg);
        write_log ("Requesting line:%3d\n", addr);
        
        sub_image(addr, image_out);
        image_out[96] = '\0';
        write_log ("%s\n", image_out);
    	break;
        
    case 'h':
        write_log ("Hello world!\n");
        break;

    default:
        break;
    }
}

int main (void)
{
    int i;
    uint16_t cnt = 0;

    // Initialise LEDs
    for (i = 0; i < LEDS_NUM; i++)
	   leds[i] = led_init (&leds_cfg[i]);

    // Set initial state to off.
    led_set (leds[0], 0);
    led_set (leds[1], 0);
    led_set (leds[2], 0);
    
    // Initialise USB.
    usb_cdc = usb_cdc_init ();
    
    // Redirect printf to USB serial.
    sys_redirect_stdin ((void *)usb_cdc_read, usb_cdc);
    sys_redirect_stdout ((void *)usb_cdc_write, usb_cdc);
    sys_redirect_stderr ((void *)usb_cdc_write, usb_cdc);
    
    // Intialise dip-switches.
    pio_config_set(DIP_SWITCH_1, PIO_PULLUP);
	pio_config_set(DIP_SWITCH_2, PIO_PULLUP);
	pio_config_set(DIP_SWITCH_3, PIO_PULLUP);
	pio_config_set(DIP_SWITCH_4, PIO_PULLUP);	

    // Initialise TCM8230.
    tcm8230_init (&cfg);
    
    // Initialise I2C.
    twi = twi_init(&twi_cfg);
    
    // Initialise the pacer.
    pacer_init (LOOP_POLL_RATE);    // 1000 Hz.

    while (1)
    {  
        // Hold up. Don't run super fast!
        pacer_wait();
        
        // Poll TWI.
        twi_poll(twi);

        // If USB is connected...        
        if (usb_cdc_update ())
    	{
            // Note any errors returned from the camera.
            if (image_ret < 0)
                write_log ("TCM8230 error: %d\r\n", (int)image_ret);
            
            // If we're about to recieve anything sent over i2c...
            if (usb_cdc_read_ready_p (usb_cdc))
                process_command();
        }
        
        // Toggle an LED at 2Hz.
        cnt++;
        if (cnt > (LOOP_POLL_RATE / LED_FLASH_FREQ / 2))
        {
            led_toggle(leds[0]);
            cnt = 0;
        } 
        
        // Decay the capture and line request LEDs.
        if (led_capture_decay > 0)
            led_capture_decay--;
        else if (led_capture_decay == 0)
            led_set(leds[1], 0);
            
        if (led_linereq_decay > 0)
            led_linereq_decay--;
        else if (led_linereq_decay == 0)
            led_set(leds[2], 0);
    }
}
