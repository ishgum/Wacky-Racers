
/* File:   ledflash1.c
   Author: M. P. Hayes, UCECE
   Date:   15 May 2007
   Descr:  Flash an LED
*/

#include <pio.h>
#include <pwm.h>
#include "target.h"
#include "pacer.h"
#include "dipswitch.h"
#include "drivingdriver.h"
#include <stdio.h>
#include <string.h>
#include <twi.h>

#define SLAVE_ADDR 0x42

#define INTERNAL_ADDR 1
#define INTERNAL_ADDR_SIZE 1
#define MESSAGE_SIZE 8

#define PWM1_FREQ_HZ 50
#define PWM2_FREQ_HZ 50
#define PWM3_FREQ_HZ 50
#define PWM_UPDATE_HZ 20
#define IRDelay 1000

#define maxRight 933
#define maxLeft 915
#define centre 924
#define maxForwards 950
#define stop 942
#define maxReverse 934

#define ACCELERATE 1
#define DECELERATE 0

typedef struct motorz_struct
{
	uint8_t motor;
	uint8_t value;
} motorz;


static const pwm_cfg_t pwm1_cfg =
{
    .pio = MOTORPWM_PIO,
    .period = PWM_PERIOD_DIVISOR (PWM1_FREQ_HZ),
    .duty = PWM_DUTY_DIVISOR (PWM1_FREQ_HZ, 93),
    .align = PWM_ALIGN_LEFT,
    .polarity = PWM_POLARITY_LOW
};

static const pwm_cfg_t pwm2_cfg =
{
    .pio = STEERINGPWM_PIO,
    .period = PWM_PERIOD_DIVISOR (PWM2_FREQ_HZ),
    .duty = PWM_DUTY_DIVISOR (PWM2_FREQ_HZ, 93),
    .align = PWM_ALIGN_LEFT,
    .polarity = PWM_POLARITY_LOW
};



static const twi_cfg_t twi_cfg =
{
    .slave_addr = SLAVE_ADDR
};


uint8_t motor = 0;
uint8_t value = 0;

motorz twi_poll (twi_t twi, pwm_t motorPWM)
{
    static char message[MESSAGE_SIZE];
    //static uint8_t addr;
    //static uint8_t value;

	
    twi_ret_t ret;
    char packet[MESSAGE_SIZE + INTERNAL_ADDR_SIZE];

	
    ret = twi_slave_poll (twi);
    switch (ret)
    {
    case TWI_IDLE:
		//return move;
        break;
        
    case TWI_WRITE:
        ret = twi_slave_read (twi, &packet, sizeof(packet));
        if (ret < 0)
        {
            /* Error, perhaps the link was broken?  */
            pio_output_high (LED3_PIO);
        }
        else if (ret == 1)
        {
            /* Assume one byte internal addresses.  */
            //motor = packet[0];
			
            /* A read request will be hot on our heels.  */
            twi_poll (twi, motorPWM);
        }
        else if (ret != sizeof (packet))
        {
            /* Protocol error.  */
            pio_output_high (LED3_PIO);
        }
        else
        {
			motor = packet[0];
            value = packet[1];
            pio_output_set (LED1_PIO, value & 1);
        }
        //return move;
        break;
        
    case TWI_READ:
        pio_output_toggle (LED2_PIO);
        message[0] = value;
        ret = twi_slave_write (twi, message, sizeof(message));
        if (ret != 1)
            pio_output_high (LED3_PIO);
            /*if (troggle){
				updateMotorPWM(1, 0, maxForwards, motorPWM);
				troggle = !troggle;
			}
			else {
				updateMotorPWM(1, 0, stop, motorPWM);
				troggle = !troggle;
			}
			* */
			//return move;
            break;
        
    default:
    //return move;
    break;
    }
}


/* Define how fast ticks occur.  This must be faster than
   TICK_RATE_MIN.  */
enum {LOOP_POLL_RATE = 2000};

/* Define LED flash rate in Hz.  */
enum {LED_FLASH_RATE = 1};

int
main (void)
{
    uint32_t main_loop_ticks;
    uint32_t pwm_update_ticks;
    uint32_t timTheTimer;
    uint8_t decreasing;
    uint8_t decreasing1;
    uint16_t dutyC;
    uint16_t dutyB;

    /* Configure LED PIO as output.  */
    pio_config_set (LED1_PIO, PIO_OUTPUT_LOW);
    pio_config_set (LED2_PIO, PIO_OUTPUT_LOW);
    pio_config_set (LED3_PIO, PIO_OUTPUT_LOW);
    pio_config_set (SLEEP_PIO, PIO_PULLUP);
    enableDipswitch();
    pio_config_set(RXPOWER_PIO, PIO_OUTPUT_HIGH);
	
	movementState current = 
	{
		.linear = stop,
		.lateral = centre
	};
    
    
    
    pacer_init (LOOP_POLL_RATE);
    main_loop_ticks = 0;
    
    timTheTimer = 0;
    


	
	pwm_t motorPWM;
	motorPWM = pwm_init (&pwm1_cfg);
	pwm_start (motorPWM);
    
    
    pwm_t steeringPWM;
    steeringPWM = pwm_init (&pwm2_cfg);
    pwm_start (steeringPWM);
    
   
	uint8_t accelerating = 1;
	uint32_t timer3 = 0;
	bool troggle = 0;
			
	twi_t twi;
	twi = twi_init(&twi_cfg);
    while (1)
    {
	/* Wait until next clock tick.  */
	pacer_wait ();
	//motorHalt(current, motorPWM);
	motor = 0;
	value = 0;
	twi_poll(twi, motorPWM);
	
	//updateMotorPWM(1, 0, stop, motorPWM);
	
	uint32_t timer2 = 0;
	
	if (motor == 1){
		
		int_fast16_t power = stop + (maxForwards - stop) * (value-127)/128;
		updateMotorPWM(1, 0, power, motorPWM);
		timTheTimer = 3000;
		/*
		if (value < 64){
			updateMotorPWM(1, 0, maxForwards , motorPWM);
		}
		else {
			updateMotorPWM(1, 1, stop, motorPWM);
		}
		* */
	}
	if (motor == 2){

		int_fast16_t power = (centre + (maxRight-centre)*(value-128)/128);
		updateTurnPWM(power, steeringPWM);
		timTheTimer = 3000;
		}
	
	if (timer2 <= 0 || timTheTimer == 3000){
		timer2 = 12000/timTheTimer;
		
		timer3 = 400;
		pio_output_high(LED1_PIO);
	}
	if (timer3 == 0){
		pio_output_low(LED1_PIO);
	}
	timTheTimer -= 1;
	timer3 -= 1;
	timer2 -= 1;
	/*
	if (getDipswitchMode() >= 10){
		motorHalt(current.linear, motorPWM);
	}
	else if ((current.linear < maxForwards) && accelerating){
		//current.linear = motorSpeed(1, current.linear, motorPWM);
		updateMotorPWM(1, 0, current.linear, motorPWM);
		current.linear += 1;
		pio_output_high(LED1_PIO);
	}
	else if ((current.linear > maxReverse) && !accelerating){
		//current.linear = motorSpeed(0, current.linear, motorPWM);
		updateMotorPWM(0, 0, current.linear, motorPWM);
		current.linear -= 1;
		pio_output_low(LED1_PIO);
	}
	else if (current.linear <= maxReverse){
		accelerating = 1;
		pio_output_toggle(LED2_PIO);
	}
	else {
		accelerating = 0;
		pio_output_toggle(LED2_PIO);
	}
	//

	
	if (current.linear == stop){
		pio_output_high(LED3_PIO);
	}
	else{
		pio_output_low(LED3_PIO);
	}
	*/
	
	/* CALIBRATION CODE
	if (getDipswitchMode() == 8){
		updateMotorPWM(0, 0, stop, motorPWM);
	}
	if (getDipswitchMode() == 4){
		updateMotorPWM(0, 0, maxForwards, motorPWM);
	}
	if (getDipswitchMode() == 2){
		updateMotorPWM(0, 0, maxReverse, motorPWM);
	}
	* */
	
		
	
	
	
	/* Turn LED on if dipswitch 1 active */
	if ((getDipswitchMode() >= 14) && !pio_output_get(LED2_PIO)) 
	{
		pio_output_high(LED2_PIO);
	}
	else
	{
		pio_output_low(LED2_PIO);
	}
}
}
