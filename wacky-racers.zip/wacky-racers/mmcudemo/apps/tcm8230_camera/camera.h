#ifndef CAMERA_H
#define CAMERA_H

#include <pio.h>
#include "target.h"
#include "pacer.h"
#include "led.h"
#include "usb_cdc.h"
#include "sys.h"

// LED configuration
static const led_cfg_t leds_cfg[] =
{
	{
		.pio = LED1_PIO,
		.active = 0
	},
	{
		.pio = LED2_PIO,
		.active = 0
	},
	{
		.pio = LED3_PIO,
		.active = 0
	}
};

enum {LEDS_NUM = ARRAY_SIZE(leds_cfg)};
led_t leds[LEDS_NUM];

// USB_CDC configuration.
usb_cdc_t usb_cdc;

// Define how fast the loop runs in Hz.
enum {LOOP_POLL_RATE = 200};

#endif