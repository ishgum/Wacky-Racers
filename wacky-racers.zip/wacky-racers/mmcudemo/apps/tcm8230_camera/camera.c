/* File:   camera.c
   Author: Chris MacEwn, based on work by M. P. Hayes, UCECE
   Date:   30 April 2015
*/
#include "camera.h"

void setup(void)
{
    int i;
    
    // Initialise LEDs.
    for (i = 0; i < LEDS_NUM; i++)
        leds[i] = led_init (&leds_cfg[i]);
        
    led_set (leds[0], 0);
    led_set (leds[1], 0);
    led_set (leds[2], 0);
    
    // Initialise the dip switches.
    pio_init (DIP_SWITCH_1);
    pio_config_set (DIP_SWITCH_1, PIO_PULLUP);
    pio_init (DIP_SWITCH_2);
    pio_config_set (DIP_SWITCH_2, PIO_PULLUP);
    pio_init (DIP_SWITCH_3);
    pio_config_set (DIP_SWITCH_3, PIO_PULLUP);
    pio_init (DIP_SWITCH_4);
    pio_config_set (DIP_SWITCH_4, PIO_PULLUP);
    
    // Initialise the USB controller and stdout.
    usb_cdc = usb_cdc_init ();
    
    sys_redirect_stdin ((void *)usb_cdc_read, usb_cdc);
    sys_redirect_stdout ((void *)usb_cdc_write, usb_cdc);
    sys_redirect_stderr ((void *)usb_cdc_write, usb_cdc);
    
    // Pause until USB is configured.
    while (! usb_cdc_update())
        continue;
        
    // Configure the pacer loop.
    pacer_init (LOOP_POLL_RATE);
}

void loop(void)
{
    // Check the dipswitches and update the LED states accordingly.
    led_set(leds[0], !(pio_input_get(DIP_SWITCH_1)));
    led_set(leds[1], !(pio_input_get(DIP_SWITCH_2)));
    
    // Check if USB is disconneted.
    led_set(leds[2], usb_cdc_update());
    
    // Wait until next clock tick.
	pacer_wait ();
}

int main (void) {
    setup();
    while (1) { loop(); }
}