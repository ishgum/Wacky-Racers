/* Nothing to do.  All the functions are inline and defined in pio.h  */

