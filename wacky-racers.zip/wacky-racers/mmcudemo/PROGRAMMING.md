Use pwd at root of project.
    
	sudo kextunload -b com.apple.driver.AppleUSBFTDI
    
	openocd -f mat91lib/sam4s/scripts/sam4s_ft2232.cfg

To upload program to microcontroller.
    
	make program
    
To debug program using gdb on microcontroller.
    
	make debug
	
To capture an image from the camera board.

	python imagecap.py
	
To capture & display an image from the camera board.

	python imagecap.py > /tmp/pic3.txt && python colourdisplay.py
