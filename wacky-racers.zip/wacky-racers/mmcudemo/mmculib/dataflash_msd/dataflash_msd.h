#ifndef DATAFLASH_MSD_H
#define DATAFLASH_MSD_H

#include "msd.h"

msd_t *dataflash_msd_init (void);

#endif
