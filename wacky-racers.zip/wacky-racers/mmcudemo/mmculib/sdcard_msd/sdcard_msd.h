#ifndef SDCARD_MSD_H
#define SDCARD_MSD_H

#include "msd.h"

msd_t *sdcard_msd_init (void);

#endif
