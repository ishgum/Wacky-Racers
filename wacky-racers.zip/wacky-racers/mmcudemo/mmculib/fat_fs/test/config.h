#ifndef CONFIG_H
#define CONFIG_H

#include <stdint.h>

typedef int bool;

#define __packed__ __attribute__((packed))

#endif
