#include "fat.h"


int
fat_fsck (fat_t *fat)
{
    



}
