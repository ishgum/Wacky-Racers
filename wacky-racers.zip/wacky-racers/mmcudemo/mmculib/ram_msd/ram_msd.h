#ifndef RAM_MSD_H
#define RAM_MSD_H

#include "msd.h"

msd_t *ram_msd_init (void);

#endif
